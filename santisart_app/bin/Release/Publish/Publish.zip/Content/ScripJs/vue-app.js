﻿new Vue({
    el: "#vue-app",
    data: {
        message:"Hello world"
    }
})